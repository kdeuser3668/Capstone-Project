# PlannerPals Backend (Node.js + SQL Server)

This is the backend API for PlannerPals.  
Built with **Express + Node.js** and connected to **SQL Server (AWS)**.

---

## Setup Instructions

### 1. Clone repo
```bash
git clone https://github.com/<your-team-org>/planner-backend.git
cd planner-backend
